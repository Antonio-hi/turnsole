# -*- coding: utf-8 -*-
# @Author        : lk
# @Email         : 9428.al@gmail.com
# @Created Date  : 2021-03-04 16:56:27
# @Last Modified : 2021-03-04 17:16:57
# @Description   :

import setuptools

setuptools.setup()